import SVG from './SVG';
import * as cola from 'webcola';

export default class Nadrs {

  constructor(opts) {

    this.models = {
      'module': {selector: 'defs>.nadrs_cont', collider: 'Rectangle', width: 250, height: 150},
      'hub': {selector: 'defs>.nhub_cont', collider: 'Ellipse', width: 400, height: 400},
    }

    let defaults = {
      // cont: undefined,
      id: undefined,
      type: 'module', //svg base model
      nodes: new Map(), //list of all nodes
      connections: new Map(), //list of all connections

      elem: undefined, //SVG.js element
      dom: undefined, //element.node,

      width: undefined,
      height: undefined,
      x: SVG.viewbox().width * Math.random(),
      y: SVG.viewbox().height * Math.random(),

      props: {},
      oldProps: {},
      
    }

    Object.assign(this, defaults, opts);

    this.width = this.models[this.type].width;
    this.height = this.models[this.type].height;

    // console.log(SVG);

    this.create();

  }

  create() {

    this.nodes.set(this.id, this);

    let model = SVG.findOne(this.models[this.type].selector);

    this.elem = model.clone();

    this.dom = this.elem.node;

    this.elem.move(this.x, this.y);
    this.elem.width(this.width);
    this.elem.height(this.height);

    SVG.put(this.elem);

    this.addDraggable();

    this.updateProperties();

    this.updateConnection();
    this.update('connection');
    this.update('type');

  }

  calcBounds(type) {

    let e = this.elem;
    let x = e.attr('x');
    let y = e.attr('y');
    let w = e.attr('width');
    let h = e.attr('height');

    this.bounds = new cola.Rectangle(x, x + w, y, y + h);

    return this.bounds;
  }

  update(key) {

    let format = {
      'connectionId': 'updateConnection',
      'type': 'updateType',
      'message': 'updateMessage',
    }

    let method = format[key];

    if(method in this && key in this.props) {
      this[method]();
    }

  }

  //dynamic callable methods from this.update()

  'updateType'() {

    const disSelector = '.disabled_value';
    const typeDoms = this.dom.querySelectorAll('.type');

    for (const typeDom of typeDoms) {
      typeDom.classList.add(disSelector);
    }

    const enabledSelectorsList = {
      '0': [], // none
      '1': ['.nadrs_output', '.nadrs_output_val'], // input
      '2': ['.nadrs_input', '.nadrs_input_val'], // output
      '3': ['.nadrs_input', '.nadrs_input_val', '.nadrs_output', '.nadrs_output_val'] // input/output
    }

    const enabledSelectors = enabledSelectorsList[this.props.type];

    for (const enabledSelector of enabledSelectors) {
      let currDom = this.dom.querySelector(enabledSelector);
      currDom.classList.remove(disSelector);
    }

  }

  'updateConnection'() {

    let id = this.props.connectionId;

    if(!node) {
      // console.log(id + ' does not exist');
      return;
    }

    let connections = this.getConnections(id);

    if(connection) {
      this.removeConnection();
      // this.connections.set(this.nameConnectionTo(id), connection);
    }

    this.createConnection();

  }

  getConnections(id) {

    let returnValue = {};

    for(let [connectionName, connection] of this.connections.entries()) {

      if(connectionName.includes(id) && connectionName.includes(this.id)) {
        returnValue = {connectionName, connection};
        break;
      }
    }

    return returnValue;

  }

  updateMessage() {

    console.log('value updated');

    let id = this.props.connectionId;
    let node = this.nodes.get(id);

    console.log('hey', id);

    if(!node)
      return;

    node.setProperty('input', this.props.message);

  }

  updateProperties(newProps = this.props) {

    for (let key in newProps) {

      let newValue = newProps[key];
      this.setProperty(key, newValue);
      // console.log(newProps, key);
      // Object.assign(this.props[key], newValue);

    }

  }

  setProperty(key, value = '') {

    this.oldProps[key] = this.props[key];
    this.props[key] = value;

    let maps = {
      "hubName": {selector: ".nhub_name", ignored: []},
      "name": {selector: ".nadrs_name", ignored: []},
      "address": {selector: ".nadrs_itwoc", ignored: []},
      "message": {selector: ".nadrs_output_val", ignored: ["none"]},
      "input": {selector: ".nadrs_input_val", ignored: ["none"]},
    }

    if(!(key in maps))
      return;

    let map = maps[key];

    if(map.ignored.indexOf(value) !== -1)
      return;

    let dom = this.dom.querySelector(map.selector);

    if(!dom)
      return;

    dom.textContent = value;

  }

  addDraggable() {

    let dragObj = this.elem.draggable();

    dragObj.on('mousedown', (e) => {
      //move on top
      SVG.put(this.elem);
    });

    dragObj.on('dragmove', (e) => {

      document.body.dispatchEvent(new CustomEvent('nodedragmove', { bubbles: true, detail: {} }));
      // this.updateConnection();
      // this.relativeDragend(e);
    });

    dragObj.on('dragend', (e) => {

      document.body.dispatchEvent(new CustomEvent('nodedragend', { bubbles: true, detail: {} }));
      // this.updateConnection();
      // this.relativeDragend(e);
    });

  }

  destroy() {

    this.elem.remove();
    this.removeConnections();
    this.nodes.delete(this.id);

  }

  relativeDragend(e) {

    let elem = this.elem;
    let viewBox = SVG.viewbox();
    let boundingRect = SVG.node.getBoundingClientRect();

    let abs = {
      x: elem.attr('x'),
      y: elem.attr('y'),
      width: viewBox.width || boundingRect.width, //fallback value if viewBox gives "0 0 0 0"
      height: viewBox.height || boundingRect.height,
    };

    let rel = {
      x: abs.x/abs.width * 100,
      y: abs.y/abs.height * 100,
    };

    elem.move(rel.x + '%', rel.y + '%');

  }
}

class Connection {
  constructor(options) {

    let defaults = {

      connections: undefined,
      nodes: undefined,
      firstNodeId: undefined,
      secondNodeId: undefined,
      type: 'default',

      gravity: 200,

      id: undefined,
      springs: {},
      selector: undefined,
      typeParams: undefined,
    }

    let types: {
      'default': {selector: 'defs>.nadrs_connection'}
    }
    

    Object.assign(this, defaults, options);

    this.typeParams = this.types[this.type];

    this.create();
  }

  create() {

    let springs = {};
    let path = SVG.findOne(this.typeParams.selector).clone();

    SVG.put(path);

    this.setSpringTo(this.firstNodeId);
    this.setSpringTo(this.secondNodeId);

    this.id = `${this.firstNodeId} - ${this.secondNodeId}`;

    this.connections.set(this.id, this);

  }

  update() {

    for (const nodeId in this.springs) {

      let spring = this.springs[nodeId];
      let nodeElem = this.nodes.get[nodeId].elem;

      spring.update({
        x: nodeElem.attr('x') + nodeElem.attr('width') * 0.5,
        y: nodeElem.attr('y') + nodeElem.attr('height') * 0.5
      });

    }

  }

  setSpringTo(id) {

    this.springs[id] = new Springy({
      gravity: this.gravity,
    });

  }

  destroy() {
    this.connections.delete(this.id);
  }

}

class Springy {

  constructor(options) {

    let defaults = {

      pos: {x: 0, y: 0},
      target: {x: 0, y: 0},
      strength: {x: 0.1, y: 0.2},
      drag: {x: 0.8, y: 0.8},
      vel: {x: 0, y: 0},
      gravity: 10,

    }

    Object.assign(this, defaults, options);

    // this.pos.y += this.gravity;

  }

  update(target = this.target) {

   // target = mouseX;
   let force = {};

   force.x = target.x - this.pos.x;
   force.y = target.y  + this.gravity - this.pos.y;

   force.x *= this.strength.x;
   force.y *= this.strength.y;

   this.vel.x *= this.drag.x;
   this.vel.y *= this.drag.y;
   
   this.vel.x += force.x;
   this.vel.y += force.y;

   this.pos.x += this.vel.x;
   this.pos.y += this.vel.y;

 }
}