export default {
	apiKey: 'AIzaSyDyi-PtW0m_0dK1MzX6x-Vha9W_yS19Y80',
	authDomain: 'ecal-mit-hub.firebaseapp.com',
	projectId: 'ecal-mit-hub',
	databaseURL: 'https://ecal-mit-hub.firebaseio.com',
	storageBucket: 'ecal-mit-hub.appspot.com',
	messagingSenderId: '1088993903670',
	appId: '1:1088993903670:web:5d9e6bac6498480b19c497'
}