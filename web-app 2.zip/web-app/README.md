 # Here And There - Connections interface

Work in progress. Contains bugs.

## Installation

 1. Clone this repository.
 2. Get the file *development.js* containing the Firebase configuration from a contributor of this repository.
 3. Put it in the folder *./config/development.js*.
 4. Do `npm install` in the main folder.

## Run for development

Do `npm run dev` in the main folder.
